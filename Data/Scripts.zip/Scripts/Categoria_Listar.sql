--OBTENER CATEGORIAS
CREATE PROCEDURE [dbo].[Categoria_Listar] 

AS
BEGIN
    SELECT * FROM Categoria
END
